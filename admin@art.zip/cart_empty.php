
<?php 
    include("header.php");
?>

<!-- banner-inner -->
<div class="banner-inner">
    <div class="container">
        <div class="row">
	        <div class="col-lg-6 col-md-6 col-sm-6 col-sx-12">
	            <h3>Buy Now</h3>
	        </div>
	        <div class="col-lg-6 col-md-6 col-sm-6 col-sx-12">
	            <ul>
	                <li><a href="index.php">Home</a></li>
	                <li>//</li>
	                <li class="active">Cart_Empty</li>
	            </ul>
	        </div>	        
	     </div> 
	</div>     
</div>
<!--// banner-inner -->

<!-- terms Start -->
<div class="cart_empty">
  	<div class="container">
  		<div class="row">
          <div class="col-md-12 col-sm-12 col-xm-12" style="text-align: center;">
              <img src="images/Cart-empty.gif" alt="" style="width: 40%;" />
              <h3>Welcome to Cart Empty</h3>
          </div>
  		</div>
  	</div>
</div>

<!--// terms End -->










<?php 
    include("footer.php");
?>