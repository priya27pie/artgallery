


			<div class="col-md-3">
				<div class="side-bar-two">
					<div class="col-md-3" style="padding: 0;">
					 <span class="glyphicon glyphicon-user"></span>
					</div>
					<div class="col-md-7">
						<p>Hello,</p>
						<h4 style="font-size: 13px;"><?=$_SESSION['login_user']?></h4>
					</div>
					<div class="clearfix"></div>
				</div>					
				<div class="category">
				<ul>
						<li><a href="profile.php">My Account</a></li>
						<li><a href="orders.php">Open Orders</a></li>
						<li><a href="logout.php">Logout</a></li>

					</ul>
				</div>
		</div>